﻿' Name:         Emoji Project
' Purpose:      Display a message corresponding to an emoji.
' Programmer:   <your name> on <current date>

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub picCrying_Click(sender As Object, e As EventArgs) Handles picCrying.Click
        lblMessage.Text = "I am crying."
    End Sub

    Private Sub picHappy_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        lblMessage.Text = "I am happy."
    End Sub

    Private Sub picLove_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        lblMessage.Text = "I am in love."
    End Sub

    Private Sub picSad_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        lblMessage.Text = "I am sad."
    End Sub

    Private Sub picTired_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        lblMessage.Text = "I am tired."
    End Sub
End Class
